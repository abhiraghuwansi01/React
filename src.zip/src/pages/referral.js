import React from 'react';
import Header from '../component/header';

import '../style/home.css';

import Footer from '../component/footer';
import Referrallink from '../component/referrallink';
import Referralboard from '../component/referralboard';

export default function Referral() {
  return (
    <div>
    <div className='home-header'>  <Header /></div>
      <div className='home-main'>
      <div className='home-main-content'>
     <Referrallink />
     <Referralboard />
      </div>
      <div className='home-footer'> 
      <Footer />
      </div>
     
      </div>
    </div>
  );
}