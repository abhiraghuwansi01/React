import React from 'react';
import Header from '../component/header';
import Coinlayer from '../component/coin-layer';
import '../style/home.css';
import Circle from '../component/circle';
import Footer from '../component/footer';
import Scoreline from '../component/scoreline';

export default function Home() {
  return (
    <div>
      <Header />
      <div className='home-main'>
      <div className='home-main-content'>
      <Coinlayer />
      <Circle />
      <Scoreline />
      </div>
      <div className='home-footer'> 
      <Footer />
      </div>
    </div>
    </div>
  );
}