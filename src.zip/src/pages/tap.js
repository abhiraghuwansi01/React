import React from 'react';
import Header from '../component/header';
import Coinlayer from '../component/coin-layer';
import '../style/home.css';
import Circle from '../component/circle';
import Scoreline from '../component/scoreline';
import Footer from '../component/footer';

export default function Tap() {
  return (
    <div>
    <div className='home-header'>  <Header /></div>
      <div className='home-main'>
      <div className='home-main-content'>
      <Coinlayer />
      <Circle />
      <Scoreline />
      </div>
      <div className='home-footer'> 
      <Footer />
      </div>
      </div>
    </div>
  );
}