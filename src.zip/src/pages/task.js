import React from 'react';
import Header from '../component/header';

import '../style/home.css';
import Circle from '../component/circle';
import Scoreline from '../component/scoreline';
import Footer from '../component/footer';
import Taskbar from '../component/taskbar';

export default function Task() {
  return (
    <div>
    <div className='home-header'>  <Header /></div>
      <div className='home-main'>
      <div className='home-main-content'>
      <Taskbar />
      <Circle />
      <Scoreline />
      </div>
      <div className='home-footer'> 
      <Footer />
      </div>
      </div>
    </div>
  );
}