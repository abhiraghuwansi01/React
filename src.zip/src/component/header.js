import React from 'react';
import '../style/header.css';
export default function Header() {
  return (
    <div className='header'>
    <div className='container'>
        <div className='row px-4 pt-3'>
            <div className='col-12 p-1 bg-current rounded-t-lg'>
              
            </div>
        </div>
       <div className='row text-center text-light justify-content-center align-items-center pt-2 pb-2 px-1 bg-[#22484F]'>
         <div className='col-4'>
          <p className='mb-0'>Cancel</p>
         </div>
         <div className='col-4'>
         <p className='mb-0'>MayBeCoin</p>
         <p className='mb-0 text-sm text-slate-400'>Bot</p>
         </div>
         <div className='col-4'>
         <p className='mb-0'>More</p>
         </div>
       </div>
    </div>
    </div>
  )
}
