import React from 'react';
import '../style/score.css';
import mytrophy1 from '../img/4544521 1.png';
export default function Scoreline() {
  return (
    <div className='score'>
    <div className='container'>
        <div className='row justify-content-center align-items-center'>
            <div className='col-12'>
             <p className='text-white d-flex justify-content-center align-items-center text-lg gap-1'><img src={mytrophy1} alt='coin' width={15} height={15} /> <span>480</span>/<span className='text-slate-600'>500</span></p>
             <progress class="progress progress1" max="100" value="90"></progress>
            </div>
         
         
            </div>
        </div>
    </div>

  )
}
