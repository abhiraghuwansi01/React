import React from 'react';
import { Link } from 'react-router-dom';

import '../style/footer.css';
import myicon1 from '../img/5326999 3 (1).png';
import myicon2 from '../img/5326999 3 (2).png';
import myicon3 from '../img/5326999 3 (3).png';
import myicon4 from '../img/5326999 3 (4).png';
import myicon5 from '../img/5326999 3.png';
export default function Footer() {
  return (
    <div className='footer'>
    <div className='container'>
        <div className='row pt-3 justify-content-center align-items-center'>
            <div className='col-1'>
              
            </div>
            <div className='col-2 p-3 text-center border column1'>
           <Link to="/referral">
              <img src={myicon1} alt='icon1' className='icon1 opacity-50' />
              <p className='text-white text-xs text-center opacity-50'> Referral  </p>
              </Link>
            </div>
            <div className='col-2 border p-3 text-center column2'>
            <Link to="/task">
            <img src={myicon2} alt='icon2' className='icon1 opacity-50' />
            <p className='text-white text-xs opacity-50'> Task  </p>
            </Link>
            </div>
            <div className='col-2 border p-3 text-center column3'>
            <Link to="/tap">
            <img src={myicon3} alt='icon3' className='icon1 opacity-50' />
            <p className='text-white text-xs opacity-50'> Tap  </p>
            </Link>
            </div>
            <div className='col-2 border p-3 text-center column4'>
            <Link to="/boost">
            <img src={myicon4} alt='icon4' className='icon1 opacity-50' />
            <p className='text-white text-xs opacity-50'> Boost  </p>
            </Link>
            </div>
            <div className='col-2 border p-3 text-center column5'>
            <Link to="/stats">
            <img src={myicon5} alt='icon5' className='icon1 opacity-50' />
            <p className='text-white text-xs opacity-50'> Stats  </p>
            </Link>
            </div>
            <div className='col-1'>
              
            </div>
        </div>
       
       </div>
    </div>
   
  )
}
