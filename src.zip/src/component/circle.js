import React from 'react';
import '../style/circle.css';
import mycircle from '../img/Transparent PNG file-01 1.png';
export default function Circle() {
  return (
    <div className='circle'>
        <div className='container'>
            <div className='row'>
                <div className='col-2'>

                </div>
                <div className='col-8'>
                    <img src={mycircle} alt='circle' width='100%' />
                </div>
                <div className='col-2'>
                    
                </div>
            </div>
        </div>
    </div>
  )
}
