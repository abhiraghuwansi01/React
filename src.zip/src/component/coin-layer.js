import React from 'react';
import '../style/coinlayer.css';
import mycoin from '../img/circle-dynamic-premium.png';
import mytrophy from '../img/trophy.png';
import myvector from '../img/Vector (1).svg';


export default function Coinlayer() {
  return (
    <div className='coin'>
    <div className='container px-3'>
    <div className='coin-content'>
        <div className='row d-flex justify-content-center align-items-center ps-2'>
          
            <div className='col-3 d-flex justify-content-center'>
              <img src={mycoin} alt='coin' width={25} />
              <p className='text-light mx-1 text-2xl'>25</p>
            </div>
            <div className='col-2'>
             
            </div>
            <div className='col-2'>
             
            </div>
            <div className='col-5'>
              <div className='trophy d-flex justify-content-center align-items-center p-1'>
              <img src={mytrophy} alt='trophy' width={15} height={15} />
              <p className='text-light mx-1 text-sm d-flex justify-content-center align-items-center'>Bronz <span className='mt-1 ps-1'><img src={myvector} alt='trophy' width={6} height={6} className='img-vector' /></span></p>
              </div>
            </div>
            </div>
        </div>
        </div>
        </div>
        
  )
}
