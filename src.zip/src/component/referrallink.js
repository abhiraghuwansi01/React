import React from 'react'
import '../style/referrallink.css';
import myicon6 from '../img/Frame.png';
import { Button } from 'react-bootstrap';

export default function Referrallink() {
  return (
    <div className='link-referral'>
    <div className='container'>
        <div className='row'>
            <div className='col-12 text-center p-4'>
                <div className='content-ref text-center'>
              <h4 className='text-white text-3xl font-semibold'>0 Referral </h4>
              </div>
            </div>
            <div className='col-12 text-center px-4'>
                <div className='div-content p-3 d-flex flex-column justify-content-center align-items-center' style={{ minHeight: '100%' }}>
      <h6 className='text-white text-xl mb-2 font-semibold'>My invite link</h6>
      <p className='text-white text-sm mb-2'>https://t.me/maybetoken_bot?start=r=14525Fgh</p>
      <Button className='text-white d-flex justify-content-center align-items-center btn-referral'>
        Copy <img src={myicon6} alt='icon1' className='icon6' />
      </Button>
      </div>
    </div>
    </div>
</div>
</div>
  )
}
