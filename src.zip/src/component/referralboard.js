import React from 'react'
import '../style/referrallink.css';
import myicon7 from '../img/5326999 4.png';
export default function Referralboard() {
  return (
    <div className='referral-board'>
    <div className='container'>
        <div className='row'>
            <div className='col-12 text-center p-3'>
                <div className='content-ref text-center pt-1 pb-1'>
              <h4 className='text-white text-xl font-semibold'>My Referrals </h4>
              </div>
            </div>
            <div className='col-12 text-center score-referral'>
                <div className='div-content1 relative p-3 d-flex flex-column justify-content-center align-items-center' style={{ minHeight: '100%' }}>
                <img src={myicon7} alt='icon1' className='icon7 grayscale' />
      <p className='text-white text-sm mb-2'>You don’t have referrals</p>
      
      <div class="overlay"></div>
      </div>
    </div>
    </div>
</div>
</div>
  )
}
