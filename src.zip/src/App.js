import React from 'react';
import './App.css';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import Home from './pages/home';
import Referral from './pages/referral';
import Task from './pages/task';
import Tap from './pages/tap';
import Boost from './pages/boostpage';
import Stats from './pages/stats';

function App() {
  return (
    <div className='App-layout'>
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/referral" element={<Referral />} />
        <Route path="/task" element={<Task />} />
        <Route path="/tap" element={<Tap />} />
        <Route path="/boost" element={<Boost />} />
        <Route path="/stats" element={<Stats />} />
      </Routes>
    </Router>
    </div>
  );
}

export default App;
